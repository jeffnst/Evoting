<ul class="sidebar-menu">
  <li class="header">MAIN NAVIGATION</li>
  <li class="active treeview">
    <a href="<?php echo base_url('admin') ?>">
      <i class="fa fa-dashboard "></i> <span>Dashboard</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>

  </li>
  <li class="treeview">
    <a href="<?php echo base_url() ;?>admin/data_pemilih">
      <i class="fa fa-users text-green"></i>
      <span>Data Pemilih Tetap</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
  </li>

  <li class="treeview">
    <a href="<?php echo base_url('admin/kandidat') ?>">
      <i class="fa fa-file-text-o text-yellow"></i>
      <span>Data Kandidat</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>

  </li>
<li class="">
    <a href="<?php echo base_url('admin/laporan') ?>">
      <i class="fa fa-bar-chart text-purple"></i>
      <span>Laporan</span>
      <span class="pull-right-container">
        
      </span>
    </a>

  <li class="">
    <a href="<?php echo base_url('admin/sandi') ?>">
      <i class="fa fa-laptop text-aqua"></i>
      <span>Pengaturan Sandi</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>

  </li>

 


  </li>
  <li><a href="<?php echo base_url() ;?>login/logout"><i class="fa fa-power-off text-red text-bold"></i> <span>Keluar</span></a></li>
</ul>
