<!DOCTYPE html>
<html>
<body onload="window.print();">






</body>
</html>
